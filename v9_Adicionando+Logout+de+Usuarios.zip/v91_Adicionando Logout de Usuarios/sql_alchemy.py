from flask_sqlalchemy import SQLAlchemy

banco = SQLAlchemy()
